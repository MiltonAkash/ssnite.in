<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8"/>
        <meta name="viewport" content="width=device-width,initial-scale=1.0"/>
        <title>FAQ & INSTRUCTIONS</title>
    </head>
    <style>
        @media only screen and (max-width:768px){
            .lap{
                display:none;
            }
        }
        @media only screen and (min-width:768px){
            .mob{
                display:none;
            }
        }
    </style>
    <body>
        <h1>SIGN UP</h1>
        <ol>
            <li>Go to <a href="http://ssnite.in/signup">ssnite.in/signup</a></li>
            <li>Fill your details like Name,dept etc. GIve your password</li>
            <li>click submit</li>
            <li>If( error occurs)
                <ol>
                    <li>Inform me
                </ol>
            </li>
            <li>No error successful signup
                <ol>
                    <li>You are added as an inactive Member.
                    <li>Your nearest activated volunteer will be informe
                    <li>You will be activated by him
                    <li>If you are not activated by anyone inform me.
                </ol>
            </li>
        </ol>
        <h1>
            VPANEL
        </h1>
        <ol>
            <li>GO to <a href="http://ssnite.in">ssnite.in</a>
            <li class="lap"> You can see notification panel at left side </li>
            <li class="mob"> You can see notification panel at bottom </li>
            <li>There you can see input boxes for mobile and password
            <li> Enter the mobile number and password (which u gave during signup)
            <li>click submit button</li>
            <li>If it takes you to vpanel
                <ul>
                    <li>It means you are activated.
                <ul>
                
            </li>
            <li>If you are in same page. check liite below
                <ul>
                    <li>If it says Unauthorized it means you are not signed up or wrong login details. contact me
                    <li>If it says Inactive someone will activate you. contact your class volunteers, or contact me
                <ul>
            </li>
        </ol>
        
        <h1>USING VPanel</h1>
        <p>Using Vpanel you can do the following things
        <ul>
            
        </ul>
        
        
    </body>
</html>
